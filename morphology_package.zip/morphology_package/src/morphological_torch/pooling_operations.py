import torch

from .pooling_autograd import MaxPool2DAutogradFunction, MinPool2DAutogradFunction, \
    ParameterizedMaxPool2DAutogradFunction, ParameterizedMinPool2DAutogradFunction


class Pool2D(torch.nn.Module):

    def __init__(self, kernel_size: int, stride: int = 2, device: int = 0) -> None:
        super(Pool2D, self).__init__()
        self.ks = kernel_size
        self.stride = stride
        self.device = device

    def extra_repr(self) -> str:
        return f'kernel_size={self.ks}, stride={self.stride}'


class MaxPool2D(Pool2D):

    def __init__(self, kernel_size: int, stride: int = 2, device: int = 0) -> None:
        super(MaxPool2D, self).__init__(kernel_size, stride, device)

    def forward(self, f: torch.Tensor) -> torch.Tensor:
        return MaxPool2DAutogradFunction.apply(f, self.ks, self.stride, self.device)


class MinPool2D(Pool2D):

    def __init__(self, kernel_size: int, stride: int = 2, device: int = 0) -> None:
        super(MinPool2D, self).__init__(kernel_size, stride, device)

    def forward(self, f: torch.Tensor) -> torch.Tensor:
        return MinPool2DAutogradFunction.apply(f, self.ks, self.stride, self.device)


class ParameterizedPool2D(Pool2D):

    def __init__(self, in_channels, kernel_size=3, stride=2, init='zero', device: int = 0):
        super(ParameterizedPool2D, self).__init__(kernel_size, stride, device)
        self.in_channels = in_channels
        h = torch.empty((in_channels, kernel_size, kernel_size))
        if init == 'zero':
            torch.nn.init.zeros_(h)
        else:
            torch.nn.init.kaiming_uniform_(h)
        self.h = torch.nn.parameter.Parameter(h, requires_grad=True)


class ParameterizedMaxPool2D(ParameterizedPool2D):

    def __init__(self, in_channels, kernel_size=3, stride=2, init='zero', device: int = 0):
        super(ParameterizedMaxPool2D, self).__init__(in_channels, kernel_size, stride, init, device)

    def forward(self, f: torch.Tensor) -> torch.Tensor:
        return ParameterizedMaxPool2DAutogradFunction.apply(f, self.h, self.stride, self.device)


class ParameterizedMinPool2D(ParameterizedPool2D):

    def __init__(self, in_channels, kernel_size=3, stride=2, init='zero', device: int = 0):
        super(ParameterizedMinPool2D, self).__init__(in_channels, kernel_size, stride, init, device)

    def forward(self, f: torch.Tensor) -> torch.Tensor:
        return ParameterizedMinPool2DAutogradFunction.apply(f, self.h, self.stride, self.device)


class ParabolicPool2D(Pool2D):

    def __init__(self, in_channels, kernel_size=3, stride=2, init='zero', device: int = 0):
        super(ParabolicPool2D, self).__init__(kernel_size, stride, device)
        self.in_channels = in_channels
        # The parabolic kernels are parameterized by t, with h(z) = -(||z||**2) / 4t where I omit 4, because
        # it is a constant.
        t = torch.empty((in_channels, ))
        if init == 'zero':
            # Init to make the centre 0 (it always is, and the corner elements -1).
            torch.nn.init.zeros_(t)
        else:
            torch.nn.init.kaiming_uniform_(t)
        self.t = torch.nn.parameter.Parameter(t, requires_grad=True)

    def _compute_parabolic_kernel(self):
        z_i = torch.linspace(-self.ks // 2 + 1, self.ks // 2, self.ks,
                             dtype=torch.float32).to(torch.device(self.device))
        z_c = z_i.view(-1, 1) ** 2 + z_i.view(1, -1) ** 2
        # Normalize, such that the corner elements are 1.
        z_c = z_c / z_c[0, 0]
        # Then repeat for however many kernels we need.
        z = torch.repeat_interleave(z_c.unsqueeze(0), self.in_channels, dim=0)
        # Create the parabolic kernels.
        return - z * self.t.view(-1, 1, 1)

    def forward(self, f: torch.Tensor) -> torch.Tensor:
        h = self._compute_parabolic_kernel()
        # And return the standard CUDA dilation.
        return ParameterizedMaxPool2DAutogradFunction.apply(f, h, self.stride, self.device)


class ParabolicMaxPool2D(ParabolicPool2D):

    def __init__(self, in_channels, kernel_size=3, stride=2, init='zero', device: int = 0):
        super(ParabolicMaxPool2D, self).__init__(in_channels, kernel_size, stride, init, device)

    def forward(self, f: torch.Tensor) -> torch.Tensor:
        # Compute the parabolic kernel.
        h = self._compute_parabolic_kernel()
        # And return the standard CUDA dilation.
        return ParameterizedMaxPool2DAutogradFunction.apply(f, h, self.stride, self.device)


class ParabolicMinPool2D(ParabolicPool2D):

    def __init__(self, in_channels, kernel_size=3, stride=2, init='zero', device: int = 0):
        super(ParabolicMinPool2D, self).__init__(in_channels, kernel_size, stride, init, device)

    def forward(self, f: torch.Tensor) -> torch.Tensor:
        # Compute the parabolic kernel.
        h = self._compute_parabolic_kernel()
        # And return the standard CUDA dilation.
        return ParameterizedMinPool2DAutogradFunction.apply(f, h, self.stride, self.device)
