## This is a test
Run
`python setup.py install`